<?php

namespace AmeliaBooking\Domain\Repository\Notification;

use AmeliaBooking\Domain\Repository\BaseRepositoryInterface;

/**
 * Interface NotificationRepositoryInterface
 *
 * @package AmeliaBooking\Domain\Repository\Notification
 */
interface NotificationRepositoryInterface extends BaseRepositoryInterface
{

}
