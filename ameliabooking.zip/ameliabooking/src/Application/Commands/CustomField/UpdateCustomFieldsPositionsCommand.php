<?php

namespace AmeliaBooking\Application\Commands\CustomField;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateCustomFieldsPositionsCommand
 *
 * @package AmeliaBooking\Application\Commands\CustomField
 */
class UpdateCustomFieldsPositionsCommand extends Command
{

}
