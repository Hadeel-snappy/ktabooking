<?php

namespace AmeliaBooking\Application\Commands\Settings;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateSettingsCommand
 *
 * @package AmeliaBooking\Application\Commands\Settings
 */
class UpdateSettingsCommand extends Command
{

}
