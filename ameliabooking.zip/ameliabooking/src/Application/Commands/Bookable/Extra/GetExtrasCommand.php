<?php

namespace AmeliaBooking\Application\Commands\Bookable\Extra;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetExtrasCommand
 *
 * @package AmeliaBooking\Application\Commands\Bookable\Extra
 */
class GetExtrasCommand extends Command
{

}
