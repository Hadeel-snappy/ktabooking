<?php

namespace AmeliaBooking\Application\Commands\User\Customer;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateCustomerCommand
 *
 * @package AmeliaBooking\Application\Commands\User\Customer
 */
class UpdateCustomerCommand extends Command
{

    /**
     * AddCustomerCommand constructor.
     *
     * @param $args
     */
    public function __construct($args)
    {
        parent::__construct($args);
    }
}
