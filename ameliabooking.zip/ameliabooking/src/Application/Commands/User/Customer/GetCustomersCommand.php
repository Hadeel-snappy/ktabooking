<?php

namespace AmeliaBooking\Application\Commands\User\Customer;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetCustomersCommand
 *
 * @package AmeliaBooking\Application\Commands\User\Customer
 */
class GetCustomersCommand extends Command
{

}
