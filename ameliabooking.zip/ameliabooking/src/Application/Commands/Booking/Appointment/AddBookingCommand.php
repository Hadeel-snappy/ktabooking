<?php

namespace AmeliaBooking\Application\Commands\Booking\Appointment;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class AddBookingCommand
 *
 * @package AmeliaBooking\Application\Commands\Booking\Appointment
 */
class AddBookingCommand extends Command
{

}
